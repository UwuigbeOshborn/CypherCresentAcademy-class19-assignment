﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass19Assignment
{
    public class MyCustomLinkedList<T>
    {
        public ListNode<T> Head { get; set; }
        public ListNode<T> Tail { get; set; }
        private int count;

        public int Count
        {
            get
            {
                return this.count;
            }
        }
        public void AddItem(T item)
        {
            if (Head is null)
            {
                Head = Tail = new ListNode<T>(item);
                count++;
            }
            else
            {
                var temp = Tail;
                var newNode = new ListNode<T>(item, temp);
                Tail.NextNode = newNode;
                Tail = newNode;
                count++;
            }
        }

        public void AddNode(ListNode<T> node)
        {
            if (Head is null)
            {
                Head = Tail = node;
            }
            else
            {
                Tail.NextNode = node;
                Tail = node;
            }

        }
        public void AddFirst(T item)
        {
            if (Head is null)
            {
                Head = Tail = new ListNode<T>(item);
                count++;
            }
            else
            {
                var temp = Head;
                var newNode = new ListNode<T>(item, null, temp);
                Head = newNode;
                Tail.PreviousNode = Head;
                count++;
            }
        }
        public void AddLast(T item)
        {
            if (Head is null)
            {
                Head = Tail = new ListNode<T>(item);
                count++;
            }
            else
            {
                var temp = Tail;
                var newNode = new ListNode<T>(item, temp);
                Tail.NextNode = newNode;
                Tail = newNode;
                count++;
            }
        }

        public ListNode<T> Find(T item)
        {
            for (ListNode<T> current = Head; current.NextNode != null; current = current.NextNode)
            {
                if (Equals(current.Value, item))
                {
                    return current;
                }
            }
            return null;
        }
        public void Remove(T item)
        {
            var nodeToRemove = Find(item);
            if (nodeToRemove is null)
            {
                return;
            }
            else
            {
                var prev = nodeToRemove.PreviousNode;
                var next = nodeToRemove.NextNode;
                if (prev != null) prev.NextNode = next;
                if (next != null) next.PreviousNode = prev;
                nodeToRemove.PreviousNode = nodeToRemove.NextNode = null;
            }
            count--;
        }
        public void RemoveLast()
        {
            if (Head == Tail)
            {
                Head = Tail = null;
                count = 0;
            }
            else
            {
                var temp = Tail.PreviousNode;
                Tail.PreviousNode = null;
                Tail = temp;
                count--;
            }
        }
        public void Clear(ListNode<T> node)
        {
            Head = Tail = null;
            count = 0;
        }
    }
}
