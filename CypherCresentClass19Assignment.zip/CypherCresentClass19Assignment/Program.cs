﻿// See https://aka.ms/new-console-template for more information
using CypherCresentClass19Assignment;

Console.WriteLine("----------------- Question 1    --------------");
var newList = new List<int>();

var mySecondList = new LinkedList<int>();

var myList = new MyCustomLinkedList<int>();

myList.AddItem(1);
myList.AddItem(2);
myList.AddItem(3);
myList.AddFirst(5);
myList.AddFirst(8);
myList.AddFirst(7);
myList.AddFirst(2);
myList.RemoveLast();
myList.Remove(5);

Console.WriteLine(myList);


for (int i = 0; i < myList.Count; i++)
{
    Console.WriteLine($"{i}");
}
//myList.Clear(myList);
